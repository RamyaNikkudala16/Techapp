# Circl — Community Connect App
**WAR for Tomcat 11 + Java 17 (Amazon Corretto)**

---

## Prerequisites
| Tool | Version |
|------|---------|
| Java | 17 (Amazon Corretto 17) |
| Maven | 3.8+ |
| Tomcat | 11.x |
| PostgreSQL | 14+ |

---

## Project structure
```
circl-app/
├── pom.xml
├── schema.sql
└── src/main/
    ├── java/com/circl/
    │   ├── dao/          DatabasePool, UserDAO, CommunityDAO, PostDAO, EventDAO
    │   ├── filter/       AuthFilter, CORSFilter
    │   ├── model/        User, Community, Post, Event
    │   └── servlet/      AuthServlet, UserServlet, CommunityServlet,
    │                     PostServlet, EventServlet, HealthServlet, AppServlet,
    │                     BaseServlet, JwtUtil
    └── webapp/
        ├── WEB-INF/web.xml
        ├── index.html
        ├── css/app.css
        └── js/app.js
```

---

## 1 — Database setup
```bash
psql -U postgres
\i schema.sql
```

Create the DB user:
```sql
CREATE USER circl_user WITH PASSWORD 'changeme';
GRANT ALL PRIVILEGES ON DATABASE circl TO circl_user;
GRANT ALL ON ALL TABLES IN SCHEMA public TO circl_user;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO circl_user;
```

---

## 2 — Configuration
Edit `src/main/webapp/WEB-INF/web.xml` and update these `<context-param>` values:

| Param | Default | Notes |
|-------|---------|-------|
| `db.url` | `jdbc:postgresql://localhost:5432/circl` | Change host/port if needed |
| `db.user` | `circl_user` | DB username |
| `db.password` | `changeme` | DB password |
| `jwt.secret` | *(change this!)* | Must be 32+ chars for security |
| `jwt.expiry.hours` | `24` | Token expiry |

---

## 3 — Build the WAR
```bash
cd circl-app

# Use Amazon Corretto 17
export JAVA_HOME=/path/to/corretto-17
export PATH=$JAVA_HOME/bin:$PATH

mvn clean package -DskipTests

# WAR is at:
target/circl.war
```

---

## 4 — Deploy to Tomcat 11
```bash
# Option A: Copy WAR to webapps
cp target/circl.war /opt/tomcat/webapps/

# Option B: Tomcat Manager (http://localhost:8080/manager)
# Upload WAR via the web UI

# Restart Tomcat
/opt/tomcat/bin/shutdown.sh
/opt/tomcat/bin/startup.sh
```

---

## 5 — Verify
```bash
# Health check
curl http://localhost:8080/circl/api/health

# Expected:
# {"status":"UP","app":"Circl Community Connect","version":"1.0.0",...}

# Open browser
open http://localhost:8080/circl/
```

---

## API Reference

### Auth (no token required)
| Method | URL | Body | Description |
|--------|-----|------|-------------|
| POST | `/api/auth/register` | `{username,email,password,fullName,city}` | Create account |
| POST | `/api/auth/login` | `{email,password}` | Login, returns JWT |
| GET  | `/api/auth/me` | — | Current user info |

### Communities (token required for write)
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/communities` | List all (optional `?category=` `?page=` `?size=`) |
| GET | `/api/communities/search?q=` | Full-text search |
| GET | `/api/communities/mine` | My communities |
| GET | `/api/communities/{id}` | Single community |
| POST | `/api/communities` | Create community |
| POST | `/api/communities/{id}/join` | Join |
| DELETE | `/api/communities/{id}/leave` | Leave |

### Posts (token required)
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/posts?communityId=` | List posts for community |
| POST | `/api/posts` | Create post `{communityId,content}` |
| DELETE | `/api/posts/{id}` | Delete own post |
| POST | `/api/posts/{id}/like` | Like |
| DELETE | `/api/posts/{id}/like` | Unlike |

### Events (token required for write)
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/events?communityId=` | Events for community |
| GET | `/api/events/upcoming` | Upcoming across all |
| GET | `/api/events/{id}` | Single event |
| POST | `/api/events` | Create event |
| POST | `/api/events/{id}/rsvp` | RSVP |
| DELETE | `/api/events/{id}/rsvp` | Cancel RSVP |

### Health
| Method | URL | Description |
|--------|-----|-------------|
| GET | `/api/health` | App health check |

---

## Using MySQL instead of PostgreSQL
Change the driver in `pom.xml`:
```xml
<dependency>
    <groupId>com.mysql</groupId>
    <artifactId>mysql-connector-j</artifactId>
    <version>8.4.0</version>
</dependency>
```
Change `db.url` to:
```
jdbc:mysql://localhost:3306/circl?useSSL=false&serverTimezone=UTC
```
Adjust schema.sql: replace `BIGSERIAL` → `BIGINT AUTO_INCREMENT`, `ILIKE` → `LIKE`, remove `RETURNING id` (use `getGeneratedKeys()`).

---

## Tomcat 11 notes
- Uses **Jakarta EE 10** namespace (`jakarta.servlet.*`, not `javax.servlet.*`)
- `web.xml` schema is `web-app_6_0.xsd`
- Jackson `JavaTimeModule` handles `LocalDateTime` serialization automatically
- JWT lib used: `jjwt 0.12.x` (latest API, not legacy 0.9.x)
