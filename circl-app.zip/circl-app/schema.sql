-- ============================================
-- CIRCL — PostgreSQL Schema
-- Run this once before deploying the WAR
-- ============================================

CREATE DATABASE circl;
\c circl;

-- Users
CREATE TABLE users (
    id            BIGSERIAL PRIMARY KEY,
    username      VARCHAR(50)  UNIQUE NOT NULL,
    email         VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(150),
    bio           TEXT,
    avatar_url    VARCHAR(500),
    city          VARCHAR(100),
    phone         VARCHAR(20),
    verified      BOOLEAN DEFAULT FALSE,
    created_at    TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_email    ON users(email);
CREATE INDEX idx_users_username ON users(username);

-- Communities
CREATE TABLE communities (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,
    slug            VARCHAR(200) UNIQUE NOT NULL,
    description     TEXT,
    category        VARCHAR(50) NOT NULL,   -- travel|study|yoga|work|food|creative|fitness|friends
    cover_image_url VARCHAR(500),
    created_by      BIGINT REFERENCES users(id),
    is_private      BOOLEAN DEFAULT FALSE,
    member_count    INT DEFAULT 0,
    city            VARCHAR(100),
    created_at      TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_communities_category ON communities(category);
CREATE INDEX idx_communities_members  ON communities(member_count DESC);

-- Community membership
CREATE TABLE community_members (
    community_id BIGINT REFERENCES communities(id) ON DELETE CASCADE,
    user_id      BIGINT REFERENCES users(id) ON DELETE CASCADE,
    role         VARCHAR(20) DEFAULT 'member',   -- admin | moderator | member
    joined_at    TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (community_id, user_id)
);

CREATE INDEX idx_cm_user ON community_members(user_id);

-- Posts
CREATE TABLE posts (
    id           BIGSERIAL PRIMARY KEY,
    community_id BIGINT REFERENCES communities(id) ON DELETE CASCADE,
    author_id    BIGINT REFERENCES users(id) ON DELETE SET NULL,
    content      TEXT NOT NULL,
    image_url    VARCHAR(500),
    like_count   INT DEFAULT 0,
    comment_count INT DEFAULT 0,
    created_at   TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_posts_community ON posts(community_id, created_at DESC);

-- Post likes
CREATE TABLE post_likes (
    post_id  BIGINT REFERENCES posts(id) ON DELETE CASCADE,
    user_id  BIGINT REFERENCES users(id) ON DELETE CASCADE,
    PRIMARY KEY (post_id, user_id)
);

-- Events
CREATE TABLE events (
    id             BIGSERIAL PRIMARY KEY,
    community_id   BIGINT REFERENCES communities(id) ON DELETE CASCADE,
    created_by     BIGINT REFERENCES users(id),
    title          VARCHAR(255) NOT NULL,
    description    TEXT,
    location       VARCHAR(255),
    is_online      BOOLEAN DEFAULT FALSE,
    meet_link      VARCHAR(500),
    event_date     TIMESTAMP NOT NULL,
    max_attendees  INT DEFAULT 50,
    attendee_count INT DEFAULT 0,
    created_at     TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_events_community ON events(community_id);
CREATE INDEX idx_events_date      ON events(event_date ASC);

-- Event RSVPs
CREATE TABLE event_attendees (
    event_id BIGINT REFERENCES events(id) ON DELETE CASCADE,
    user_id  BIGINT REFERENCES users(id) ON DELETE CASCADE,
    rsvp_at  TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (event_id, user_id)
);

-- Seed data (optional)
INSERT INTO communities (name, slug, description, category, created_by, member_count, city)
VALUES
    ('Bangalore Backpackers',   'bangalore-backpackers',   'Weekend trips and travel planning for Bangaloreans', 'travel',   NULL, 128, 'Bangalore'),
    ('IIT Study Circle',         'iit-study-circle',         'JEE, GATE, and competitive exam prep group',         'study',    NULL,  89, 'Bangalore'),
    ('Morning Yoga Collective',  'morning-yoga-collective',  'Daily 6 AM yoga sessions — all levels welcome',       'yoga',     NULL, 245, 'Bangalore'),
    ('Remote Work Bangalore',    'remote-work-bangalore',    'Co-working, networking, and freelancer support',       'work',     NULL, 176, 'Bangalore'),
    ('Foodie Explorers BLR',     'foodie-explorers-blr',     'Discovering the best food spots in the city',         'food',     NULL, 312, 'Bangalore'),
    ('BLR Runners Club',         'blr-runners-club',         'Morning runs, marathons, and fitness challenges',     'fitness',  NULL, 203, 'Bangalore');
