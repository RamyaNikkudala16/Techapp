/* ============================
   CIRCL — Frontend Application
   Vanilla JS, talks to REST API
   ============================ */

const API = '/circl/api';
let authToken = localStorage.getItem('circl_token');
let currentUser = JSON.parse(localStorage.getItem('circl_user') || 'null');

// ---- ROUTING ----
function showPage(name) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const page = document.getElementById('page-' + name);
    if (page) page.classList.add('active');
    window.scrollTo(0, 0);

    if (name === 'communities') loadCommunities(null, document.querySelector('.filter-btn'));
    if (name === 'events') loadEvents();
}

// ---- AUTH STATE ----
function updateNavAuth() {
    const navAuth = document.getElementById('navAuth');
    const navUser = document.getElementById('navUser');
    const createBtn = document.getElementById('createCommunityBtn');

    if (currentUser) {
        navAuth.classList.add('hidden');
        navUser.classList.remove('hidden');
        document.getElementById('navUsername').textContent = '👋 ' + currentUser.username;
        if (createBtn) createBtn.style.display = '';
    } else {
        navAuth.classList.remove('hidden');
        navUser.classList.add('hidden');
        if (createBtn) createBtn.style.display = 'none';
    }
}

function logout() {
    localStorage.removeItem('circl_token');
    localStorage.removeItem('circl_user');
    authToken = null;
    currentUser = null;
    updateNavAuth();
    showPage('home');
}

// ---- API HELPERS ----
async function apiFetch(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (authToken) headers['Authorization'] = 'Bearer ' + authToken;
    const resp = await fetch(API + path, { ...options, headers });
    const data = await resp.json().catch(() => ({}));
    return { ok: resp.ok, status: resp.status, data };
}

// ---- AUTH FLOWS ----
async function login() {
    const email    = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errEl    = document.getElementById('loginError');
    errEl.classList.add('hidden');

    if (!email || !password) { showAlert(errEl, 'Email and password are required.'); return; }

    const { ok, data } = await apiFetch('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
    });

    if (ok) {
        authToken = data.token;
        currentUser = data.user;
        localStorage.setItem('circl_token', authToken);
        localStorage.setItem('circl_user', JSON.stringify(currentUser));
        updateNavAuth();
        showPage('communities');
    } else {
        showAlert(errEl, data.message || 'Login failed.');
    }
}

async function register() {
    const fullName = document.getElementById('regName').value.trim();
    const username = document.getElementById('regUsername').value.trim();
    const email    = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const city     = document.getElementById('regCity').value.trim();
    const errEl    = document.getElementById('registerError');
    errEl.classList.add('hidden');

    if (!fullName || !username || !email || !password) {
        showAlert(errEl, 'All fields are required.'); return;
    }

    const { ok, data } = await apiFetch('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ fullName, username, email, password, city })
    });

    if (ok) {
        authToken = data.token;
        currentUser = data.user;
        localStorage.setItem('circl_token', authToken);
        localStorage.setItem('circl_user', JSON.stringify(currentUser));
        updateNavAuth();
        showPage('communities');
    } else {
        showAlert(errEl, data.message || 'Registration failed.');
    }
}

// ---- COMMUNITIES ----
let currentCategory = null;
let searchTimeout = null;

async function loadCommunities(category, btn) {
    currentCategory = category;
    if (btn) {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    }

    const el = document.getElementById('communityList');
    el.innerHTML = '<div class="loading">Loading communities...</div>';

    const path = category
        ? `/communities?category=${category}&size=24`
        : '/communities?size=24';

    const { ok, data } = await apiFetch(path);
    if (!ok) { el.innerHTML = '<div class="empty-state"><h3>Failed to load communities.</h3></div>'; return; }

    renderCommunities(data.communities || [], el);
}

function filterCommunity(category) {
    showPage('communities');
    const btn = [...document.querySelectorAll('.filter-btn')].find(b => b.textContent.toLowerCase() === category);
    loadCommunities(category, btn);
}

function searchCommunities(q) {
    clearTimeout(searchTimeout);
    if (!q.trim()) { loadCommunities(currentCategory, null); return; }
    searchTimeout = setTimeout(async () => {
        const el = document.getElementById('communityList');
        const { ok, data } = await apiFetch(`/communities/search?q=${encodeURIComponent(q)}`);
        if (ok) renderCommunities(data.communities || [], el);
    }, 350);
}

function renderCommunities(communities, el) {
    if (!communities.length) {
        el.innerHTML = '<div class="empty-state"><h3>No communities found.</h3><p>Try a different filter or create one!</p></div>';
        return;
    }
    el.innerHTML = communities.map(c => `
        <div class="community-card">
            <div class="cc-header">
                <div class="cc-name">${esc(c.name)}</div>
                <span class="cc-badge badge-${esc(c.category)}">${esc(c.category)}</span>
            </div>
            <div class="cc-desc">${esc(c.description || '')}</div>
            <div class="cc-meta">
                <span>👥 ${c.memberCount} members</span>
                ${c.city ? `<span>📍 ${esc(c.city)}</span>` : ''}
            </div>
            <div class="cc-actions">
                <button class="btn btn-outline" onclick="viewCommunity(${c.id})">View</button>
                ${authToken ? `<button class="btn btn-primary" onclick="joinCommunity(${c.id}, this)">Join</button>` : ''}
            </div>
        </div>
    `).join('');
}

async function joinCommunity(id, btn) {
    if (!authToken) { showPage('login'); return; }
    btn.disabled = true;
    const { ok, data } = await apiFetch(`/communities/${id}/join`, { method: 'POST' });
    if (ok) {
        btn.textContent = '✓ Joined';
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline');
    } else {
        btn.disabled = false;
        alert(data.message || 'Failed to join.');
    }
}

async function viewCommunity(id) {
    showPage('community-detail');
    const el = document.getElementById('communityDetailContent');
    el.innerHTML = '<div class="loading">Loading...</div>';

    const { ok, data: community } = await apiFetch(`/communities/${id}`);
    if (!ok) { el.innerHTML = '<div class="empty-state"><h3>Community not found.</h3></div>'; return; }

    el.innerHTML = `
        <div class="community-detail-hero">
            <span class="cc-badge badge-${esc(community.category)}">${esc(community.category)}</span>
            <h1>${esc(community.name)}</h1>
            <p>${esc(community.description || '')}</p>
            <div class="detail-meta">
                👥 ${community.memberCount} members
                ${community.city ? ` &nbsp;•&nbsp; 📍 ${esc(community.city)}` : ''}
            </div>
            <div class="detail-actions">
                ${authToken ? `<button class="btn btn-primary" onclick="joinCommunity(${community.id}, this)">Join community</button>` : ''}
                <button class="btn btn-outline" onclick="showPage('communities')">← Back</button>
            </div>
        </div>
        <div class="posts-section">
            <h3>Posts</h3>
            ${authToken ? `
            <div class="post-box">
                <textarea id="newPostContent" rows="3" placeholder="Share something with the community..."></textarea>
                <div class="post-box-actions">
                    <button class="btn btn-primary" onclick="createPost(${community.id})">Post</button>
                </div>
            </div>` : ''}
            <div id="postList"><div class="loading">Loading posts...</div></div>
        </div>
    `;

    loadPosts(id);
}

// ---- POSTS ----
async function loadPosts(communityId) {
    const el = document.getElementById('postList');
    const { ok, data } = await apiFetch(`/posts?communityId=${communityId}`);
    if (!ok) { el.innerHTML = '<div class="empty-state"><h3>Could not load posts.</h3></div>'; return; }
    const posts = data.posts || [];
    if (!posts.length) {
        el.innerHTML = '<div class="empty-state"><h3>No posts yet.</h3><p>Be the first to post!</p></div>';
        return;
    }
    el.innerHTML = posts.map(p => `
        <div class="post-card">
            <div>
                <span class="post-author">${esc(p.authorName || 'Unknown')}</span>
                <span class="post-time">${timeAgo(p.createdAt)}</span>
            </div>
            <div class="post-content">${esc(p.content)}</div>
            <div class="post-actions">
                <button class="post-like-btn" onclick="likePost(${p.id}, this)">
                    ♥ ${p.likeCount} likes
                </button>
            </div>
        </div>
    `).join('');
}

async function createPost(communityId) {
    const content = document.getElementById('newPostContent').value.trim();
    if (!content) return;
    const { ok } = await apiFetch('/posts', {
        method: 'POST',
        body: JSON.stringify({ communityId, content })
    });
    if (ok) {
        document.getElementById('newPostContent').value = '';
        loadPosts(communityId);
    }
}

async function likePost(postId, btn) {
    if (!authToken) { showPage('login'); return; }
    const { ok } = await apiFetch(`/posts/${postId}/like`, { method: 'POST' });
    if (ok) {
        const cur = parseInt(btn.textContent.match(/\d+/)?.[0] || '0');
        btn.textContent = `♥ ${cur + 1} likes`;
    }
}

// ---- EVENTS ----
async function loadEvents() {
    const el = document.getElementById('eventList');
    el.innerHTML = '<div class="loading">Loading events...</div>';
    const { ok, data } = await apiFetch('/events/upcoming?size=20');
    if (!ok) { el.innerHTML = '<div class="empty-state"><h3>Failed to load events.</h3></div>'; return; }
    const events = data.events || [];
    if (!events.length) {
        el.innerHTML = '<div class="empty-state"><h3>No upcoming events.</h3></div>';
        return;
    }
    el.innerHTML = events.map(e => `
        <div class="community-card">
            <div class="cc-header">
                <div class="cc-name">${esc(e.title)}</div>
                <span class="cc-badge">${e.isOnline ? 'Online' : 'In-person'}</span>
            </div>
            <div class="cc-desc">${esc(e.description || '')}</div>
            <div class="cc-meta">
                <span>📅 ${formatDate(e.eventDate)}</span>
                <span>👥 ${e.attendeeCount}/${e.maxAttendees}</span>
                ${e.location ? `<span>📍 ${esc(e.location)}</span>` : ''}
            </div>
            <div class="cc-actions">
                ${authToken ? `<button class="btn btn-primary" onclick="rsvpEvent(${e.id}, this)">RSVP</button>` : ''}
            </div>
        </div>
    `).join('');
}

async function rsvpEvent(eventId, btn) {
    if (!authToken) { showPage('login'); return; }
    btn.disabled = true;
    const { ok, data } = await apiFetch(`/events/${eventId}/rsvp`, { method: 'POST' });
    if (ok) {
        btn.textContent = '✓ RSVP\'d';
        btn.classList.remove('btn-primary');
    } else {
        btn.disabled = false;
        alert(data.message || 'RSVP failed.');
    }
}

// ---- CREATE COMMUNITY ----
async function createCommunity() {
    if (!authToken) { showPage('login'); return; }
    const name     = document.getElementById('ccName').value.trim();
    const category = document.getElementById('ccCategory').value;
    const desc     = document.getElementById('ccDesc').value.trim();
    const city     = document.getElementById('ccCity').value.trim();
    const isPrivate = document.getElementById('ccPrivate').checked;
    const errEl    = document.getElementById('createCommunityError');

    if (!name || !desc) { showAlert(errEl, 'Name and description are required.'); return; }

    const { ok, data } = await apiFetch('/communities', {
        method: 'POST',
        body: JSON.stringify({ name, category, description: desc, city, isPrivate })
    });

    if (ok) {
        showPage('communities');
        loadCommunities(null, document.querySelector('.filter-btn'));
    } else {
        showAlert(errEl, data.message || 'Failed to create community.');
    }
}

// ---- UTILS ----
function esc(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function showAlert(el, msg) {
    el.textContent = msg;
    el.classList.remove('hidden');
}

function timeAgo(iso) {
    if (!iso) return '';
    const diff = Date.now() - new Date(iso).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return m + 'm ago';
    const h = Math.floor(m / 60);
    if (h < 24) return h + 'h ago';
    return Math.floor(h / 24) + 'd ago';
}

function formatDate(iso) {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// ---- INIT ----
updateNavAuth();
showPage('home');
