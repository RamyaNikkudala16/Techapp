package com.circl.model;

import java.time.LocalDateTime;

public class Community {
    private Long id;
    private String name;
    private String slug;          // URL-friendly e.g. "yoga-bangalore"
    private String description;
    private String category;      // travel, study, yoga, work, food, creative, fitness, friends
    private String coverImageUrl;
    private Long createdBy;
    private boolean isPrivate;
    private int memberCount;
    private String city;
    private LocalDateTime createdAt;

    public Community() {}

    public Community(String name, String description, String category, Long createdBy) {
        this.name = name;
        this.slug = name.toLowerCase().replaceAll("[^a-z0-9]+", "-");
        this.description = description;
        this.category = category;
        this.createdBy = createdBy;
        this.isPrivate = false;
        this.memberCount = 1;
        this.createdAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSlug() { return slug; }
    public void setSlug(String slug) { this.slug = slug; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getCoverImageUrl() { return coverImageUrl; }
    public void setCoverImageUrl(String coverImageUrl) { this.coverImageUrl = coverImageUrl; }

    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }

    public boolean isPrivate() { return isPrivate; }
    public void setPrivate(boolean aPrivate) { isPrivate = aPrivate; }

    public int getMemberCount() { return memberCount; }
    public void setMemberCount(int memberCount) { this.memberCount = memberCount; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
