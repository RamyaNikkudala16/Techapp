package com.circl.model;

import java.time.LocalDateTime;

public class Event {
    private Long id;
    private Long communityId;
    private Long createdBy;
    private String title;
    private String description;
    private String location;
    private boolean isOnline;
    private String meetLink;
    private LocalDateTime eventDate;
    private int maxAttendees;
    private int attendeeCount;
    private LocalDateTime createdAt;

    public Event() {}

    public Event(Long communityId, Long createdBy, String title, String description, LocalDateTime eventDate) {
        this.communityId = communityId;
        this.createdBy = createdBy;
        this.title = title;
        this.description = description;
        this.eventDate = eventDate;
        this.attendeeCount = 0;
        this.maxAttendees = 50;
        this.createdAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getCommunityId() { return communityId; }
    public void setCommunityId(Long communityId) { this.communityId = communityId; }
    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public boolean isOnline() { return isOnline; }
    public void setOnline(boolean online) { isOnline = online; }
    public String getMeetLink() { return meetLink; }
    public void setMeetLink(String meetLink) { this.meetLink = meetLink; }
    public LocalDateTime getEventDate() { return eventDate; }
    public void setEventDate(LocalDateTime eventDate) { this.eventDate = eventDate; }
    public int getMaxAttendees() { return maxAttendees; }
    public void setMaxAttendees(int maxAttendees) { this.maxAttendees = maxAttendees; }
    public int getAttendeeCount() { return attendeeCount; }
    public void setAttendeeCount(int attendeeCount) { this.attendeeCount = attendeeCount; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
