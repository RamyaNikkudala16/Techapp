package com.circl.dao;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.servlet.ServletContext;

import java.sql.Connection;
import java.sql.SQLException;

public class DatabasePool {

    private static volatile HikariDataSource dataSource;

    private DatabasePool() {}

    public static void init(ServletContext ctx) {
        if (dataSource != null) return;
        synchronized (DatabasePool.class) {
            if (dataSource != null) return;

            String url      = ctx.getInitParameter("db.url");
            String user     = ctx.getInitParameter("db.user");
            String password = ctx.getInitParameter("db.password");

            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(url);
            config.setUsername(user);
            config.setPassword(password);
            config.setMaximumPoolSize(20);
            config.setMinimumIdle(5);
            config.setConnectionTimeout(30_000);
            config.setIdleTimeout(600_000);
            config.setMaxLifetime(1_800_000);
            config.setPoolName("CirclPool");
            // Keep connections alive on PostgreSQL
            config.setConnectionTestQuery("SELECT 1");
            config.addDataSourceProperty("cachePrepStmts", "true");
            config.addDataSourceProperty("prepStmtCacheSize", "250");
            config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

            dataSource = new HikariDataSource(config);
        }
    }

    public static Connection getConnection() throws SQLException {
        if (dataSource == null) {
            throw new IllegalStateException("DatabasePool not initialized. Call init() first.");
        }
        return dataSource.getConnection();
    }

    public static void shutdown() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }
}
