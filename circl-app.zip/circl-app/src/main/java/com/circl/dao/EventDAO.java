package com.circl.dao;

import com.circl.model.Event;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class EventDAO {

    public Event create(Event e) throws SQLException {
        String sql = """
            INSERT INTO events (community_id, created_by, title, description, location, is_online,
                                meet_link, event_date, max_attendees, attendee_count, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
            RETURNING id
            """;
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, e.getCommunityId());
            ps.setLong(2, e.getCreatedBy());
            ps.setString(3, e.getTitle());
            ps.setString(4, e.getDescription());
            ps.setString(5, e.getLocation());
            ps.setBoolean(6, e.isOnline());
            ps.setString(7, e.getMeetLink());
            ps.setTimestamp(8, Timestamp.valueOf(e.getEventDate()));
            ps.setInt(9, e.getMaxAttendees());
            ps.setTimestamp(10, Timestamp.valueOf(LocalDateTime.now()));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) e.setId(rs.getLong("id"));
        }
        return e;
    }

    public List<Event> findByCommunity(Long communityId, int page, int size) throws SQLException {
        String sql = """
            SELECT * FROM events WHERE community_id = ?
            ORDER BY event_date ASC
            LIMIT ? OFFSET ?
            """;
        List<Event> list = new ArrayList<>();
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, communityId);
            ps.setInt(2, size);
            ps.setInt(3, page * size);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public List<Event> findUpcoming(int page, int size) throws SQLException {
        String sql = """
            SELECT * FROM events WHERE event_date > NOW()
            ORDER BY event_date ASC
            LIMIT ? OFFSET ?
            """;
        List<Event> list = new ArrayList<>();
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, size);
            ps.setInt(2, page * size);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public Event findById(Long id) throws SQLException {
        String sql = "SELECT * FROM events WHERE id = ?";
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        }
        return null;
    }

    public void rsvp(Long eventId, Long userId) throws SQLException {
        String sql = """
            INSERT INTO event_attendees (event_id, user_id, rsvp_at)
            VALUES (?, ?, ?)
            ON CONFLICT (event_id, user_id) DO NOTHING
            """;
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, eventId);
            ps.setLong(2, userId);
            ps.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            int rows = ps.executeUpdate();
            if (rows > 0) {
                try (PreparedStatement ps2 = conn.prepareStatement(
                        "UPDATE events SET attendee_count = attendee_count + 1 WHERE id = ?")) {
                    ps2.setLong(1, eventId);
                    ps2.executeUpdate();
                }
            }
        }
    }

    public void cancelRsvp(Long eventId, Long userId) throws SQLException {
        String sql = "DELETE FROM event_attendees WHERE event_id = ? AND user_id = ?";
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, eventId);
            ps.setLong(2, userId);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                try (PreparedStatement ps2 = conn.prepareStatement(
                        "UPDATE events SET attendee_count = GREATEST(attendee_count - 1, 0) WHERE id = ?")) {
                    ps2.setLong(1, eventId);
                    ps2.executeUpdate();
                }
            }
        }
    }

    private Event mapRow(ResultSet rs) throws SQLException {
        Event e = new Event();
        e.setId(rs.getLong("id"));
        e.setCommunityId(rs.getLong("community_id"));
        e.setCreatedBy(rs.getLong("created_by"));
        e.setTitle(rs.getString("title"));
        e.setDescription(rs.getString("description"));
        e.setLocation(rs.getString("location"));
        e.setOnline(rs.getBoolean("is_online"));
        e.setMeetLink(rs.getString("meet_link"));
        Timestamp eventDate = rs.getTimestamp("event_date");
        if (eventDate != null) e.setEventDate(eventDate.toLocalDateTime());
        e.setMaxAttendees(rs.getInt("max_attendees"));
        e.setAttendeeCount(rs.getInt("attendee_count"));
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) e.setCreatedAt(createdAt.toLocalDateTime());
        return e;
    }
}
