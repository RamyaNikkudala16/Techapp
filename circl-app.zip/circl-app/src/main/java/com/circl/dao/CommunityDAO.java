package com.circl.dao;

import com.circl.model.Community;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CommunityDAO {

    public Community create(Community c) throws SQLException {
        String sql = """
            INSERT INTO communities (name, slug, description, category, created_by, is_private, member_count, city, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            RETURNING id
            """;
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getName());
            ps.setString(2, c.getSlug());
            ps.setString(3, c.getDescription());
            ps.setString(4, c.getCategory());
            ps.setLong(5, c.getCreatedBy());
            ps.setBoolean(6, c.isPrivate());
            ps.setInt(7, 1);
            ps.setString(8, c.getCity());
            ps.setTimestamp(9, Timestamp.valueOf(LocalDateTime.now()));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) c.setId(rs.getLong("id"));
        }
        return c;
    }

    public List<Community> findAll(int page, int size) throws SQLException {
        String sql = "SELECT * FROM communities ORDER BY member_count DESC LIMIT ? OFFSET ?";
        List<Community> list = new ArrayList<>();
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, size);
            ps.setInt(2, page * size);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public List<Community> findByCategory(String category, int page, int size) throws SQLException {
        String sql = "SELECT * FROM communities WHERE category = ? ORDER BY member_count DESC LIMIT ? OFFSET ?";
        List<Community> list = new ArrayList<>();
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, category);
            ps.setInt(2, size);
            ps.setInt(3, page * size);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public Community findById(Long id) throws SQLException {
        String sql = "SELECT * FROM communities WHERE id = ?";
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        }
        return null;
    }

    public List<Community> findByUser(Long userId) throws SQLException {
        String sql = """
            SELECT c.* FROM communities c
            JOIN community_members cm ON c.id = cm.community_id
            WHERE cm.user_id = ?
            ORDER BY c.created_at DESC
            """;
        List<Community> list = new ArrayList<>();
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public void joinCommunity(Long communityId, Long userId) throws SQLException {
        String sql = """
            INSERT INTO community_members (community_id, user_id, role, joined_at)
            VALUES (?, ?, 'member', ?)
            ON CONFLICT (community_id, user_id) DO NOTHING
            """;
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, communityId);
            ps.setLong(2, userId);
            ps.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            ps.executeUpdate();
        }
        // Update count
        String updateSql = "UPDATE communities SET member_count = member_count + 1 WHERE id = ?";
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(updateSql)) {
            ps.setLong(1, communityId);
            ps.executeUpdate();
        }
    }

    public void leaveCommunity(Long communityId, Long userId) throws SQLException {
        String sql = "DELETE FROM community_members WHERE community_id = ? AND user_id = ?";
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, communityId);
            ps.setLong(2, userId);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                String updateSql = "UPDATE communities SET member_count = GREATEST(member_count - 1, 0) WHERE id = ?";
                try (PreparedStatement ps2 = conn.prepareStatement(updateSql)) {
                    ps2.setLong(1, communityId);
                    ps2.executeUpdate();
                }
            }
        }
    }

    public List<Community> search(String query, int page, int size) throws SQLException {
        String sql = """
            SELECT * FROM communities
            WHERE name ILIKE ? OR description ILIKE ? OR category ILIKE ?
            ORDER BY member_count DESC LIMIT ? OFFSET ?
            """;
        List<Community> list = new ArrayList<>();
        String pattern = "%" + query + "%";
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, pattern);
            ps.setString(2, pattern);
            ps.setString(3, pattern);
            ps.setInt(4, size);
            ps.setInt(5, page * size);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    private Community mapRow(ResultSet rs) throws SQLException {
        Community c = new Community();
        c.setId(rs.getLong("id"));
        c.setName(rs.getString("name"));
        c.setSlug(rs.getString("slug"));
        c.setDescription(rs.getString("description"));
        c.setCategory(rs.getString("category"));
        c.setCoverImageUrl(rs.getString("cover_image_url"));
        c.setCreatedBy(rs.getLong("created_by"));
        c.setPrivate(rs.getBoolean("is_private"));
        c.setMemberCount(rs.getInt("member_count"));
        c.setCity(rs.getString("city"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) c.setCreatedAt(ts.toLocalDateTime());
        return c;
    }
}
