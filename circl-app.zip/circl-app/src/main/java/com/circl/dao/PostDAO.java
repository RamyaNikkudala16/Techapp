package com.circl.dao;

import com.circl.model.Post;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PostDAO {

    public Post create(Post post) throws SQLException {
        String sql = """
            INSERT INTO posts (community_id, author_id, content, image_url, like_count, comment_count, created_at)
            VALUES (?, ?, ?, ?, 0, 0, ?)
            RETURNING id
            """;
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, post.getCommunityId());
            ps.setLong(2, post.getAuthorId());
            ps.setString(3, post.getContent());
            ps.setString(4, post.getImageUrl());
            ps.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) post.setId(rs.getLong("id"));
        }
        return post;
    }

    public List<Post> findByCommunity(Long communityId, int page, int size) throws SQLException {
        String sql = """
            SELECT p.*, u.full_name AS author_name
            FROM posts p
            JOIN users u ON p.author_id = u.id
            WHERE p.community_id = ?
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
            """;
        List<Post> list = new ArrayList<>();
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, communityId);
            ps.setInt(2, size);
            ps.setInt(3, page * size);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public Post findById(Long id) throws SQLException {
        String sql = """
            SELECT p.*, u.full_name AS author_name
            FROM posts p
            JOIN users u ON p.author_id = u.id
            WHERE p.id = ?
            """;
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        }
        return null;
    }

    public void like(Long postId, Long userId) throws SQLException {
        // Insert like (ignore duplicate)
        String sql = "INSERT INTO post_likes (post_id, user_id) VALUES (?, ?) ON CONFLICT DO NOTHING";
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, postId);
            ps.setLong(2, userId);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                try (PreparedStatement ps2 = conn.prepareStatement(
                        "UPDATE posts SET like_count = like_count + 1 WHERE id = ?")) {
                    ps2.setLong(1, postId);
                    ps2.executeUpdate();
                }
            }
        }
    }

    public void unlike(Long postId, Long userId) throws SQLException {
        String sql = "DELETE FROM post_likes WHERE post_id = ? AND user_id = ?";
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, postId);
            ps.setLong(2, userId);
            int rows = ps.executeUpdate();
            if (rows > 0) {
                try (PreparedStatement ps2 = conn.prepareStatement(
                        "UPDATE posts SET like_count = GREATEST(like_count - 1, 0) WHERE id = ?")) {
                    ps2.setLong(1, postId);
                    ps2.executeUpdate();
                }
            }
        }
    }

    public void delete(Long postId) throws SQLException {
        try (Connection conn = DatabasePool.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM posts WHERE id = ?")) {
            ps.setLong(1, postId);
            ps.executeUpdate();
        }
    }

    private Post mapRow(ResultSet rs) throws SQLException {
        Post p = new Post();
        p.setId(rs.getLong("id"));
        p.setCommunityId(rs.getLong("community_id"));
        p.setAuthorId(rs.getLong("author_id"));
        p.setAuthorName(rs.getString("author_name"));
        p.setContent(rs.getString("content"));
        p.setImageUrl(rs.getString("image_url"));
        p.setLikeCount(rs.getInt("like_count"));
        p.setCommentCount(rs.getInt("comment_count"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) p.setCreatedAt(ts.toLocalDateTime());
        return p;
    }
}
