package com.circl.filter;

import com.circl.servlet.JwtUtil;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  req  = (HttpServletRequest)  request;
        HttpServletResponse resp = (HttpServletResponse) response;

        // Retrieve JwtUtil initialised by AuthServlet
        JwtUtil jwtUtil = (JwtUtil) req.getServletContext().getAttribute("jwtUtil");
        if (jwtUtil == null) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.setContentType("application/json");
            resp.getWriter().write("{\"error\":true,\"message\":\"Auth service not ready.\"}");
            return;
        }

        String authHeader = req.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            sendUnauthorized(resp, "Missing or invalid Authorization header.");
            return;
        }

        String token = authHeader.substring(7);
        if (!jwtUtil.isValid(token)) {
            sendUnauthorized(resp, "Invalid or expired token.");
            return;
        }

        Long userId = jwtUtil.getUserId(token);
        req.setAttribute("userId", userId);

        chain.doFilter(request, response);
    }

    private void sendUnauthorized(HttpServletResponse resp, String message) throws IOException {
        resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        resp.setContentType("application/json;charset=UTF-8");
        resp.getWriter().write(
                String.format("{\"error\":true,\"status\":401,\"message\":\"%s\"}", message)
        );
    }
}
