package com.circl.servlet;

import com.circl.dao.DatabasePool;
import com.circl.dao.EventDAO;
import com.circl.model.Event;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * GET    /api/events?communityId=&page=&size=  - list events for community
 * GET    /api/events/upcoming                   - upcoming events across all communities
 * GET    /api/events/{id}                       - single event
 * POST   /api/events                            - create event
 * POST   /api/events/{id}/rsvp                  - RSVP to event
 * DELETE /api/events/{id}/rsvp                  - cancel RSVP
 */
public class EventServlet extends BaseServlet {

    private EventDAO eventDAO;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        DatabasePool.init(config.getServletContext());
        eventDAO = new EventDAO();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String first = getPathSegment(req, 0);

        if (first == null) {
            listEvents(req, resp);
        } else if ("upcoming".equals(first)) {
            upcomingEvents(req, resp);
        } else {
            Long id = parseLong(first);
            if (id == null) { sendNotFound(resp, "Event"); return; }
            getEvent(resp, id);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long userId = getAuthUserId(req);
        if (userId == null) { sendUnauthorized(resp); return; }

        String first  = getPathSegment(req, 0);
        String second = getPathSegment(req, 1);

        if (first == null) {
            createEvent(req, resp, userId);
        } else if ("rsvp".equals(second)) {
            Long eventId = parseLong(first);
            if (eventId == null) { sendNotFound(resp, "Event"); return; }
            rsvp(resp, eventId, userId);
        } else {
            sendNotFound(resp, "Endpoint");
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long userId = getAuthUserId(req);
        if (userId == null) { sendUnauthorized(resp); return; }

        Long eventId = getPathId(req, 0);
        String second = getPathSegment(req, 1);

        if (eventId != null && "rsvp".equals(second)) {
            cancelRsvp(resp, eventId, userId);
        } else {
            sendNotFound(resp, "Endpoint");
        }
    }

    private void listEvents(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String communityIdParam = req.getParameter("communityId");
        if (communityIdParam == null) { sendBadRequest(resp, "communityId is required."); return; }
        try {
            long communityId = Long.parseLong(communityIdParam);
            int page = intParam(req, "page", 0);
            int size = intParam(req, "size", 20);
            List<Event> events = eventDAO.findByCommunity(communityId, page, size);
            sendSuccess(resp, Map.of("events", events));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void upcomingEvents(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            int page = intParam(req, "page", 0);
            int size = intParam(req, "size", 20);
            List<Event> events = eventDAO.findUpcoming(page, size);
            sendSuccess(resp, Map.of("events", events));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void getEvent(HttpServletResponse resp, Long id) throws IOException {
        try {
            Event event = eventDAO.findById(id);
            if (event == null) { sendNotFound(resp, "Event"); return; }
            sendSuccess(resp, event);
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void createEvent(HttpServletRequest req, HttpServletResponse resp, Long userId) throws IOException {
        try {
            Map<?, ?> body = readJson(req, Map.class);
            String title       = (String) body.get("title");
            String description = (String) body.get("description");
            String eventDateStr = (String) body.get("eventDate");
            Object communityIdRaw = body.get("communityId");

            if (title == null || eventDateStr == null || communityIdRaw == null) {
                sendBadRequest(resp, "title, communityId and eventDate are required.");
                return;
            }

            long communityId = ((Number) communityIdRaw).longValue();
            LocalDateTime eventDate = LocalDateTime.parse(eventDateStr, DateTimeFormatter.ISO_DATE_TIME);

            Event event = new Event(communityId, userId, title, description, eventDate);
            event.setLocation((String) body.get("location"));
            event.setMeetLink((String) body.get("meetLink"));
            if (body.get("isOnline") instanceof Boolean b) event.setOnline(b);
            if (body.get("maxAttendees") instanceof Number n) event.setMaxAttendees(n.intValue());

            event = eventDAO.create(event);
            sendCreated(resp, event);
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void rsvp(HttpServletResponse resp, Long eventId, Long userId) throws IOException {
        try {
            Event event = eventDAO.findById(eventId);
            if (event == null) { sendNotFound(resp, "Event"); return; }
            if (event.getAttendeeCount() >= event.getMaxAttendees()) {
                sendError(resp, 409, "Event is full.");
                return;
            }
            eventDAO.rsvp(eventId, userId);
            sendSuccess(resp, Map.of("message", "RSVP confirmed."));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void cancelRsvp(HttpServletResponse resp, Long eventId, Long userId) throws IOException {
        try {
            eventDAO.cancelRsvp(eventId, userId);
            sendSuccess(resp, Map.of("message", "RSVP cancelled."));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private Long parseLong(String s) {
        try { return Long.parseLong(s); } catch (Exception e) { return null; }
    }

    private int intParam(HttpServletRequest req, String name, int def) {
        try { return Integer.parseInt(req.getParameter(name)); } catch (Exception e) { return def; }
    }
}
