package com.circl.servlet;

import com.circl.dao.DatabasePool;
import com.circl.dao.UserDAO;
import com.circl.model.User;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * GET  /api/users/{id}       - get user profile
 * PUT  /api/users/{id}       - update own profile
 * GET  /api/users/{id}/communities - communities a user belongs to
 */
public class UserServlet extends BaseServlet {

    private UserDAO userDAO;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        DatabasePool.init(config.getServletContext());
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long id = getPathId(req, 0);
        if (id == null) { sendBadRequest(resp, "User ID required."); return; }

        String sub = getPathSegment(req, 1);
        if ("communities".equals(sub)) {
            getUserCommunities(req, resp, id);
        } else {
            getUser(req, resp, id);
        }
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long id = getPathId(req, 0);
        if (id == null) { sendBadRequest(resp, "User ID required."); return; }

        Long authId = getAuthUserId(req);
        if (authId == null || !authId.equals(id)) {
            sendForbidden(resp);
            return;
        }
        updateUser(req, resp, id);
    }

    private void getUser(HttpServletRequest req, HttpServletResponse resp, Long id) throws IOException {
        try {
            User user = userDAO.findById(id);
            if (user == null) { sendNotFound(resp, "User"); return; }
            sendSuccess(resp, safeUser(user));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void getUserCommunities(HttpServletRequest req, HttpServletResponse resp, Long userId) throws IOException {
        try {
            com.circl.dao.CommunityDAO communityDAO = new com.circl.dao.CommunityDAO();
            java.util.List<com.circl.model.Community> list = communityDAO.findByUser(userId);
            sendSuccess(resp, Map.of("communities", list));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void updateUser(HttpServletRequest req, HttpServletResponse resp, Long id) throws IOException {
        try {
            User user = userDAO.findById(id);
            if (user == null) { sendNotFound(resp, "User"); return; }

            Map<?, ?> body = readJson(req, Map.class);
            if (body.get("fullName") != null) user.setFullName((String) body.get("fullName"));
            if (body.get("bio") != null) user.setBio((String) body.get("bio"));
            if (body.get("avatarUrl") != null) user.setAvatarUrl((String) body.get("avatarUrl"));
            if (body.get("city") != null) user.setCity((String) body.get("city"));

            userDAO.update(user);
            sendSuccess(resp, safeUser(user));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private Map<String, Object> safeUser(User user) {
        Map<String, Object> u = new HashMap<>();
        u.put("id", user.getId());
        u.put("username", user.getUsername());
        u.put("email", user.getEmail());
        u.put("fullName", user.getFullName());
        u.put("bio", user.getBio());
        u.put("avatarUrl", user.getAvatarUrl());
        u.put("city", user.getCity());
        u.put("verified", user.isVerified());
        u.put("createdAt", user.getCreatedAt());
        return u;
    }
}
