package com.circl.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class BaseServlet extends HttpServlet {

    protected static final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

    protected void sendJson(HttpServletResponse resp, int status, Object data) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json;charset=UTF-8");
        resp.setHeader("Cache-Control", "no-cache");
        mapper.writeValue(resp.getWriter(), data);
    }

    protected void sendSuccess(HttpServletResponse resp, Object data) throws IOException {
        sendJson(resp, 200, data);
    }

    protected void sendCreated(HttpServletResponse resp, Object data) throws IOException {
        sendJson(resp, 201, data);
    }

    protected void sendError(HttpServletResponse resp, int status, String message) throws IOException {
        Map<String, Object> error = new HashMap<>();
        error.put("error", true);
        error.put("message", message);
        error.put("status", status);
        sendJson(resp, status, error);
    }

    protected void sendBadRequest(HttpServletResponse resp, String message) throws IOException {
        sendError(resp, 400, message);
    }

    protected void sendUnauthorized(HttpServletResponse resp) throws IOException {
        sendError(resp, 401, "Unauthorized. Please login.");
    }

    protected void sendForbidden(HttpServletResponse resp) throws IOException {
        sendError(resp, 403, "Forbidden.");
    }

    protected void sendNotFound(HttpServletResponse resp, String resource) throws IOException {
        sendError(resp, 404, resource + " not found.");
    }

    protected void sendServerError(HttpServletResponse resp, String message) throws IOException {
        sendError(resp, 500, message);
    }

    protected <T> T readJson(HttpServletRequest req, Class<T> clazz) throws IOException {
        String body = req.getReader().lines().collect(Collectors.joining());
        return mapper.readValue(body, clazz);
    }

    protected String getPathSegment(HttpServletRequest req, int index) {
        String pathInfo = req.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) return null;
        String[] parts = pathInfo.split("/");
        // parts[0] is empty string before leading /
        int realIndex = index + 1;
        if (parts.length > realIndex) return parts[realIndex];
        return null;
    }

    protected Long getPathId(HttpServletRequest req, int index) {
        try {
            String seg = getPathSegment(req, index);
            return seg != null ? Long.parseLong(seg) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    protected Long getAuthUserId(HttpServletRequest req) {
        Object userId = req.getAttribute("userId");
        return userId != null ? (Long) userId : null;
    }
}
