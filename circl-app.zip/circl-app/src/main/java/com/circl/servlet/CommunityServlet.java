package com.circl.servlet;

import com.circl.dao.CommunityDAO;
import com.circl.dao.DatabasePool;
import com.circl.model.Community;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * GET    /api/communities              - list all (paginated, optional ?category=)
 * GET    /api/communities/search?q=   - search communities
 * GET    /api/communities/mine        - communities I've joined
 * GET    /api/communities/{id}        - get one
 * POST   /api/communities             - create community
 * POST   /api/communities/{id}/join   - join community
 * DELETE /api/communities/{id}/leave  - leave community
 */
public class CommunityServlet extends BaseServlet {

    private CommunityDAO communityDAO;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        DatabasePool.init(config.getServletContext());
        communityDAO = new CommunityDAO();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String first = getPathSegment(req, 0);

        if (first == null) {
            listCommunities(req, resp);
        } else if ("search".equals(first)) {
            searchCommunities(req, resp);
        } else if ("mine".equals(first)) {
            myCommunities(req, resp);
        } else {
            Long id = parseLong(first);
            if (id == null) { sendNotFound(resp, "Community"); return; }
            getCommunity(req, resp, id);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String first  = getPathSegment(req, 0);
        String second = getPathSegment(req, 1);

        if (first == null) {
            createCommunity(req, resp);
        } else if ("join".equals(second)) {
            Long id = parseLong(first);
            if (id == null) { sendNotFound(resp, "Community"); return; }
            joinCommunity(req, resp, id);
        } else {
            sendNotFound(resp, "Endpoint");
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String first  = getPathSegment(req, 0);
        String second = getPathSegment(req, 1);

        if ("leave".equals(second)) {
            Long id = parseLong(first);
            if (id == null) { sendNotFound(resp, "Community"); return; }
            leaveCommunity(req, resp, id);
        } else {
            sendNotFound(resp, "Endpoint");
        }
    }

    private void listCommunities(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            int page = intParam(req, "page", 0);
            int size = intParam(req, "size", 20);
            String category = req.getParameter("category");

            List<Community> list = (category != null && !category.isBlank())
                    ? communityDAO.findByCategory(category, page, size)
                    : communityDAO.findAll(page, size);

            sendSuccess(resp, Map.of("communities", list, "page", page, "size", size));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void searchCommunities(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String q = req.getParameter("q");
        if (q == null || q.isBlank()) {
            sendBadRequest(resp, "Query parameter 'q' is required.");
            return;
        }
        try {
            int page = intParam(req, "page", 0);
            int size = intParam(req, "size", 20);
            List<Community> results = communityDAO.search(q, page, size);
            sendSuccess(resp, Map.of("communities", results, "query", q));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void myCommunities(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long userId = getAuthUserId(req);
        if (userId == null) { sendUnauthorized(resp); return; }
        try {
            List<Community> list = communityDAO.findByUser(userId);
            sendSuccess(resp, Map.of("communities", list));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void getCommunity(HttpServletRequest req, HttpServletResponse resp, Long id) throws IOException {
        try {
            Community c = communityDAO.findById(id);
            if (c == null) { sendNotFound(resp, "Community"); return; }
            sendSuccess(resp, c);
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void createCommunity(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long userId = getAuthUserId(req);
        if (userId == null) { sendUnauthorized(resp); return; }
        try {
            Map<?, ?> body = readJson(req, Map.class);
            String name        = (String) body.get("name");
            String description = (String) body.get("description");
            String category    = (String) body.get("category");

            if (name == null || description == null || category == null) {
                sendBadRequest(resp, "name, description and category are required.");
                return;
            }

            Community c = new Community(name, description, category, userId);
            c.setCity((String) body.get("city"));
            if (body.get("isPrivate") instanceof Boolean b) c.setPrivate(b);

            c = communityDAO.create(c);
            // auto-join creator as admin
            communityDAO.joinCommunity(c.getId(), userId);
            sendCreated(resp, c);
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void joinCommunity(HttpServletRequest req, HttpServletResponse resp, Long communityId) throws IOException {
        Long userId = getAuthUserId(req);
        if (userId == null) { sendUnauthorized(resp); return; }
        try {
            Community c = communityDAO.findById(communityId);
            if (c == null) { sendNotFound(resp, "Community"); return; }
            communityDAO.joinCommunity(communityId, userId);
            sendSuccess(resp, Map.of("message", "Joined community successfully.", "communityId", communityId));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void leaveCommunity(HttpServletRequest req, HttpServletResponse resp, Long communityId) throws IOException {
        Long userId = getAuthUserId(req);
        if (userId == null) { sendUnauthorized(resp); return; }
        try {
            communityDAO.leaveCommunity(communityId, userId);
            sendSuccess(resp, Map.of("message", "Left community successfully."));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private Long parseLong(String s) {
        try { return Long.parseLong(s); } catch (Exception e) { return null; }
    }

    private int intParam(HttpServletRequest req, String name, int def) {
        try { return Integer.parseInt(req.getParameter(name)); } catch (Exception e) { return def; }
    }
}
