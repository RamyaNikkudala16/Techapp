package com.circl.servlet;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.Instant;
import java.util.Map;

/**
 * GET /api/health  — returns 200 OK with uptime info.
 * Use this for Tomcat Manager health checks / load balancer probes.
 */
public class HealthServlet extends BaseServlet {

    private static final long START_TIME = System.currentTimeMillis();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        long uptimeSeconds = (System.currentTimeMillis() - START_TIME) / 1000;
        sendSuccess(resp, Map.of(
                "status", "UP",
                "app", "Circl Community Connect",
                "version", "1.0.0",
                "timestamp", Instant.now().toString(),
                "uptimeSeconds", uptimeSeconds
        ));
    }
}
