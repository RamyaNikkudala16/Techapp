package com.circl.servlet;

import com.circl.dao.DatabasePool;
import com.circl.dao.PostDAO;
import com.circl.model.Post;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * GET    /api/posts?communityId=&page=&size=   - list posts for a community
 * POST   /api/posts                             - create post
 * DELETE /api/posts/{id}                        - delete own post
 * POST   /api/posts/{id}/like                   - like a post
 * DELETE /api/posts/{id}/like                   - unlike a post
 */
public class PostServlet extends BaseServlet {

    private PostDAO postDAO;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        DatabasePool.init(config.getServletContext());
        postDAO = new PostDAO();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String communityIdParam = req.getParameter("communityId");
        if (communityIdParam == null) {
            sendBadRequest(resp, "communityId query parameter is required.");
            return;
        }
        try {
            long communityId = Long.parseLong(communityIdParam);
            int page = intParam(req, "page", 0);
            int size = intParam(req, "size", 20);
            List<Post> posts = postDAO.findByCommunity(communityId, page, size);
            sendSuccess(resp, Map.of("posts", posts, "page", page, "size", size));
        } catch (NumberFormatException e) {
            sendBadRequest(resp, "Invalid communityId.");
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long userId = getAuthUserId(req);
        if (userId == null) { sendUnauthorized(resp); return; }

        String first  = getPathSegment(req, 0);
        String second = getPathSegment(req, 1);

        if (first == null) {
            createPost(req, resp, userId);
        } else if ("like".equals(second)) {
            Long postId = parseLong(first);
            if (postId == null) { sendNotFound(resp, "Post"); return; }
            likePost(resp, postId, userId);
        } else {
            sendNotFound(resp, "Endpoint");
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long userId = getAuthUserId(req);
        if (userId == null) { sendUnauthorized(resp); return; }

        Long postId = getPathId(req, 0);
        if (postId == null) { sendBadRequest(resp, "Post ID required."); return; }

        String second = getPathSegment(req, 1);
        if ("like".equals(second)) {
            unlikePost(resp, postId, userId);
        } else {
            deletePost(resp, postId, userId);
        }
    }

    private void createPost(HttpServletRequest req, HttpServletResponse resp, Long userId) throws IOException {
        try {
            Map<?, ?> body = readJson(req, Map.class);
            String content       = (String) body.get("content");
            Object communityIdRaw = body.get("communityId");

            if (content == null || content.isBlank()) {
                sendBadRequest(resp, "content is required.");
                return;
            }
            if (communityIdRaw == null) {
                sendBadRequest(resp, "communityId is required.");
                return;
            }

            long communityId = ((Number) communityIdRaw).longValue();
            Post post = new Post(communityId, userId, content);
            post.setImageUrl((String) body.get("imageUrl"));
            post = postDAO.create(post);
            sendCreated(resp, post);
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void deletePost(HttpServletResponse resp, Long postId, Long userId) throws IOException {
        try {
            Post post = postDAO.findById(postId);
            if (post == null) { sendNotFound(resp, "Post"); return; }
            if (!post.getAuthorId().equals(userId)) { sendForbidden(resp); return; }
            postDAO.delete(postId);
            sendSuccess(resp, Map.of("message", "Post deleted."));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void likePost(HttpServletResponse resp, Long postId, Long userId) throws IOException {
        try {
            postDAO.like(postId, userId);
            sendSuccess(resp, Map.of("message", "Liked."));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private void unlikePost(HttpServletResponse resp, Long postId, Long userId) throws IOException {
        try {
            postDAO.unlike(postId, userId);
            sendSuccess(resp, Map.of("message", "Unliked."));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private Long parseLong(String s) {
        try { return Long.parseLong(s); } catch (Exception e) { return null; }
    }

    private int intParam(HttpServletRequest req, String name, int def) {
        try { return Integer.parseInt(req.getParameter(name)); } catch (Exception e) { return def; }
    }
}
