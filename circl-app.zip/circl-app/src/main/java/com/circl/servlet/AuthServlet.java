package com.circl.servlet;

import com.circl.dao.DatabasePool;
import com.circl.dao.UserDAO;
import com.circl.model.User;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.mindrot.jbcrypt.BCrypt;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * POST /api/auth/register  - create account
 * POST /api/auth/login     - get JWT
 * GET  /api/auth/me        - current user info (requires token)
 */
public class AuthServlet extends BaseServlet {

    private UserDAO userDAO;
    private JwtUtil jwtUtil;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        DatabasePool.init(config.getServletContext());
        userDAO = new UserDAO();
        String secret = config.getServletContext().getInitParameter("jwt.secret");
        int expiry = Integer.parseInt(config.getServletContext().getInitParameter("jwt.expiry.hours"));
        jwtUtil = new JwtUtil(secret, expiry);
        // Make jwtUtil available to filters via context
        config.getServletContext().setAttribute("jwtUtil", jwtUtil);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String action = getPathSegment(req, 0);
        if ("register".equals(action)) {
            handleRegister(req, resp);
        } else if ("login".equals(action)) {
            handleLogin(req, resp);
        } else {
            sendNotFound(resp, "Endpoint");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String action = getPathSegment(req, 0);
        if ("me".equals(action)) {
            handleMe(req, resp);
        } else {
            sendNotFound(resp, "Endpoint");
        }
    }

    private void handleRegister(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            Map<?, ?> body = readJson(req, Map.class);
            String username  = (String) body.get("username");
            String email     = (String) body.get("email");
            String password  = (String) body.get("password");
            String fullName  = (String) body.get("fullName");

            if (username == null || email == null || password == null || fullName == null) {
                sendBadRequest(resp, "username, email, password and fullName are required.");
                return;
            }
            if (password.length() < 8) {
                sendBadRequest(resp, "Password must be at least 8 characters.");
                return;
            }
            if (!email.contains("@")) {
                sendBadRequest(resp, "Invalid email address.");
                return;
            }
            if (userDAO.emailExists(email)) {
                sendError(resp, 409, "Email already registered.");
                return;
            }
            if (userDAO.usernameExists(username)) {
                sendError(resp, 409, "Username already taken.");
                return;
            }

            String hash = BCrypt.hashpw(password, BCrypt.gensalt(12));
            User user = new User(username, email, hash, fullName);
            user.setCity((String) body.get("city"));
            user = userDAO.create(user);

            String token = jwtUtil.generateToken(user.getId(), user.getUsername());
            sendCreated(resp, buildAuthResponse(user, token));

        } catch (Exception e) {
            sendServerError(resp, "Registration failed: " + e.getMessage());
        }
    }

    private void handleLogin(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            Map<?, ?> body = readJson(req, Map.class);
            String email    = (String) body.get("email");
            String password = (String) body.get("password");

            if (email == null || password == null) {
                sendBadRequest(resp, "email and password are required.");
                return;
            }

            User user = userDAO.findByEmail(email);
            if (user == null || !BCrypt.checkpw(password, user.getPasswordHash())) {
                sendError(resp, 401, "Invalid email or password.");
                return;
            }

            String token = jwtUtil.generateToken(user.getId(), user.getUsername());
            sendSuccess(resp, buildAuthResponse(user, token));

        } catch (Exception e) {
            sendServerError(resp, "Login failed: " + e.getMessage());
        }
    }

    private void handleMe(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String authHeader = req.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            sendUnauthorized(resp);
            return;
        }
        String token = authHeader.substring(7);
        Long userId = jwtUtil.getUserId(token);
        if (userId == null) {
            sendUnauthorized(resp);
            return;
        }
        try {
            User user = userDAO.findById(userId);
            if (user == null) {
                sendNotFound(resp, "User");
                return;
            }
            sendSuccess(resp, safeUser(user));
        } catch (Exception e) {
            sendServerError(resp, e.getMessage());
        }
    }

    private Map<String, Object> buildAuthResponse(User user, String token) {
        Map<String, Object> resp = new HashMap<>();
        resp.put("token", token);
        resp.put("user", safeUser(user));
        return resp;
    }

    private Map<String, Object> safeUser(User user) {
        Map<String, Object> u = new HashMap<>();
        u.put("id", user.getId());
        u.put("username", user.getUsername());
        u.put("email", user.getEmail());
        u.put("fullName", user.getFullName());
        u.put("bio", user.getBio());
        u.put("avatarUrl", user.getAvatarUrl());
        u.put("city", user.getCity());
        u.put("verified", user.isVerified());
        return u;
    }
}
