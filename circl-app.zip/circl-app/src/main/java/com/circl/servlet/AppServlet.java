package com.circl.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Catch-all servlet — serves index.html for SPA routes.
 * Reads the file directly from the WAR to avoid forward loops.
 */
public class AppServlet extends BaseServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        String uri = req.getRequestURI();
        String contextPath = req.getContextPath(); // e.g. /circl
        String path = uri.length() > contextPath.length()
                ? uri.substring(contextPath.length())
                : "/";

        // Static assets (css, js, png, ico, etc.) — delegate to Tomcat's DefaultServlet
        if (path.matches(".*\\.(css|js|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|map)$")) {
            req.getServletContext()
               .getNamedDispatcher("default")
               .forward(req, resp);
            return;
        }

        // All other routes (SPA routes + root) — stream index.html from the WAR
        try (InputStream in = getServletContext().getResourceAsStream("/index.html")) {
            if (in == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "index.html not found.");
                return;
            }
            resp.setContentType("text/html;charset=UTF-8");
            resp.setStatus(HttpServletResponse.SC_OK);
            try (OutputStream out = resp.getOutputStream()) {
                in.transferTo(out);
            }
        }
    }
}
